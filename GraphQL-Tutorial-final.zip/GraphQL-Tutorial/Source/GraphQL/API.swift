//  This file was automatically generated and should not be edited.

import Apollo

public final class SearchReposQuery: GraphQLQuery {
  public static let operationString =
    "query SearchRepos($searchText: String!) {\n  search(first: 20, query: $searchText, type: REPOSITORY) {\n    __typename\n    nodes {\n      __typename\n      ... on Repository {\n        ...RepositoryDetail\n      }\n    }\n  }\n}"

  public static var requestString: String { return operationString.appending(RepositoryDetail.fragmentString) }

  public var searchText: String

  public init(searchText: String) {
    self.searchText = searchText
  }

  public var variables: GraphQLMap? {
    return ["searchText": searchText]
  }

  public struct Data: GraphQLSelectionSet {
    public static let possibleTypes = ["Query"]

    public static let selections: [GraphQLSelection] = [
      GraphQLField("search", arguments: ["first": 20, "query": GraphQLVariable("searchText"), "type": "REPOSITORY"], type: .nonNull(.object(Search.selections))),
    ]

    public var snapshot: Snapshot

    public init(snapshot: Snapshot) {
      self.snapshot = snapshot
    }

    public init(search: Search) {
      self.init(snapshot: ["__typename": "Query", "search": search.snapshot])
    }

    /// Perform a search across resources.
    public var search: Search {
      get {
        return Search(snapshot: snapshot["search"]! as! Snapshot)
      }
      set {
        snapshot.updateValue(newValue.snapshot, forKey: "search")
      }
    }

    public struct Search: GraphQLSelectionSet {
      public static let possibleTypes = ["SearchResultItemConnection"]

      public static let selections: [GraphQLSelection] = [
        GraphQLField("__typename", type: .nonNull(.scalar(String.self))),
        GraphQLField("nodes", type: .list(.object(Node.selections))),
      ]

      public var snapshot: Snapshot

      public init(snapshot: Snapshot) {
        self.snapshot = snapshot
      }

      public init(nodes: [Node?]? = nil) {
        self.init(snapshot: ["__typename": "SearchResultItemConnection", "nodes": nodes.flatMap { $0.map { $0.flatMap { $0.snapshot } } }])
      }

      public var __typename: String {
        get {
          return snapshot["__typename"]! as! String
        }
        set {
          snapshot.updateValue(newValue, forKey: "__typename")
        }
      }

      /// A list of nodes.
      public var nodes: [Node?]? {
        get {
          return (snapshot["nodes"] as? [Snapshot?]).flatMap { $0.map { $0.flatMap { Node(snapshot: $0) } } }
        }
        set {
          snapshot.updateValue(newValue.flatMap { $0.map { $0.flatMap { $0.snapshot } } }, forKey: "nodes")
        }
      }

      public struct Node: GraphQLSelectionSet {
        public static let possibleTypes = ["Issue", "PullRequest", "Repository", "User", "Organization", "MarketplaceListing"]

        public static let selections: [GraphQLSelection] = [
          GraphQLTypeCase(
            variants: ["Repository": AsRepository.selections],
            default: [
              GraphQLField("__typename", type: .nonNull(.scalar(String.self))),
            ]
          )
        ]

        public var snapshot: Snapshot

        public init(snapshot: Snapshot) {
          self.snapshot = snapshot
        }

        public static func makeIssue() -> Node {
          return Node(snapshot: ["__typename": "Issue"])
        }

        public static func makePullRequest() -> Node {
          return Node(snapshot: ["__typename": "PullRequest"])
        }

        public static func makeUser() -> Node {
          return Node(snapshot: ["__typename": "User"])
        }

        public static func makeOrganization() -> Node {
          return Node(snapshot: ["__typename": "Organization"])
        }

        public static func makeMarketplaceListing() -> Node {
          return Node(snapshot: ["__typename": "MarketplaceListing"])
        }

        public static func makeRepository(id: GraphQLID, nameWithOwner: String, viewerHasStarred: Bool, stargazers: AsRepository.Stargazer) -> Node {
          return Node(snapshot: ["__typename": "Repository", "id": id, "nameWithOwner": nameWithOwner, "viewerHasStarred": viewerHasStarred, "stargazers": stargazers.snapshot])
        }

        public var __typename: String {
          get {
            return snapshot["__typename"]! as! String
          }
          set {
            snapshot.updateValue(newValue, forKey: "__typename")
          }
        }

        public var asRepository: AsRepository? {
          get {
            if !AsRepository.possibleTypes.contains(__typename) { return nil }
            return AsRepository(snapshot: snapshot)
          }
          set {
            guard let newValue = newValue else { return }
            snapshot = newValue.snapshot
          }
        }

        public struct AsRepository: GraphQLSelectionSet {
          public static let possibleTypes = ["Repository"]

          public static let selections: [GraphQLSelection] = [
            GraphQLField("__typename", type: .nonNull(.scalar(String.self))),
            GraphQLField("__typename", type: .nonNull(.scalar(String.self))),
            GraphQLField("id", type: .nonNull(.scalar(GraphQLID.self))),
            GraphQLField("nameWithOwner", type: .nonNull(.scalar(String.self))),
            GraphQLField("viewerHasStarred", type: .nonNull(.scalar(Bool.self))),
            GraphQLField("stargazers", type: .nonNull(.object(Stargazer.selections))),
          ]

          public var snapshot: Snapshot

          public init(snapshot: Snapshot) {
            self.snapshot = snapshot
          }

          public init(id: GraphQLID, nameWithOwner: String, viewerHasStarred: Bool, stargazers: Stargazer) {
            self.init(snapshot: ["__typename": "Repository", "id": id, "nameWithOwner": nameWithOwner, "viewerHasStarred": viewerHasStarred, "stargazers": stargazers.snapshot])
          }

          public var __typename: String {
            get {
              return snapshot["__typename"]! as! String
            }
            set {
              snapshot.updateValue(newValue, forKey: "__typename")
            }
          }

          public var id: GraphQLID {
            get {
              return snapshot["id"]! as! GraphQLID
            }
            set {
              snapshot.updateValue(newValue, forKey: "id")
            }
          }

          /// The repository's name with owner.
          public var nameWithOwner: String {
            get {
              return snapshot["nameWithOwner"]! as! String
            }
            set {
              snapshot.updateValue(newValue, forKey: "nameWithOwner")
            }
          }

          /// Returns a boolean indicating whether the viewing user has starred this starrable.
          public var viewerHasStarred: Bool {
            get {
              return snapshot["viewerHasStarred"]! as! Bool
            }
            set {
              snapshot.updateValue(newValue, forKey: "viewerHasStarred")
            }
          }

          /// A list of users who have starred this starrable.
          public var stargazers: Stargazer {
            get {
              return Stargazer(snapshot: snapshot["stargazers"]! as! Snapshot)
            }
            set {
              snapshot.updateValue(newValue.snapshot, forKey: "stargazers")
            }
          }

          public var fragments: Fragments {
            get {
              return Fragments(snapshot: snapshot)
            }
            set {
              snapshot += newValue.snapshot
            }
          }

          public struct Fragments {
            public var snapshot: Snapshot

            public var repositoryDetail: RepositoryDetail {
              get {
                return RepositoryDetail(snapshot: snapshot)
              }
              set {
                snapshot += newValue.snapshot
              }
            }
          }

          public struct Stargazer: GraphQLSelectionSet {
            public static let possibleTypes = ["StargazerConnection"]

            public static let selections: [GraphQLSelection] = [
              GraphQLField("__typename", type: .nonNull(.scalar(String.self))),
              GraphQLField("totalCount", type: .nonNull(.scalar(Int.self))),
            ]

            public var snapshot: Snapshot

            public init(snapshot: Snapshot) {
              self.snapshot = snapshot
            }

            public init(totalCount: Int) {
              self.init(snapshot: ["__typename": "StargazerConnection", "totalCount": totalCount])
            }

            public var __typename: String {
              get {
                return snapshot["__typename"]! as! String
              }
              set {
                snapshot.updateValue(newValue, forKey: "__typename")
              }
            }

            /// Identifies the total count of items in the connection.
            public var totalCount: Int {
              get {
                return snapshot["totalCount"]! as! Int
              }
              set {
                snapshot.updateValue(newValue, forKey: "totalCount")
              }
            }
          }
        }
      }
    }
  }
}

public final class AddStarMutation: GraphQLMutation {
  public static let operationString =
    "mutation AddStar($repositoryId: ID!) {\n  addStar(input: {clientMutationId: \"11078247\", starrableId: $repositoryId}) {\n    __typename\n    starrable {\n      __typename\n      ... on Repository {\n        ...RepositoryDetail\n      }\n    }\n  }\n}"

  public static var requestString: String { return operationString.appending(RepositoryDetail.fragmentString) }

  public var repositoryId: GraphQLID

  public init(repositoryId: GraphQLID) {
    self.repositoryId = repositoryId
  }

  public var variables: GraphQLMap? {
    return ["repositoryId": repositoryId]
  }

  public struct Data: GraphQLSelectionSet {
    public static let possibleTypes = ["Mutation"]

    public static let selections: [GraphQLSelection] = [
      GraphQLField("addStar", arguments: ["input": ["clientMutationId": "11078247", "starrableId": GraphQLVariable("repositoryId")]], type: .object(AddStar.selections)),
    ]

    public var snapshot: Snapshot

    public init(snapshot: Snapshot) {
      self.snapshot = snapshot
    }

    public init(addStar: AddStar? = nil) {
      self.init(snapshot: ["__typename": "Mutation", "addStar": addStar.flatMap { $0.snapshot }])
    }

    /// Adds a star to a Starrable.
    public var addStar: AddStar? {
      get {
        return (snapshot["addStar"] as? Snapshot).flatMap { AddStar(snapshot: $0) }
      }
      set {
        snapshot.updateValue(newValue?.snapshot, forKey: "addStar")
      }
    }

    public struct AddStar: GraphQLSelectionSet {
      public static let possibleTypes = ["AddStarPayload"]

      public static let selections: [GraphQLSelection] = [
        GraphQLField("__typename", type: .nonNull(.scalar(String.self))),
        GraphQLField("starrable", type: .nonNull(.object(Starrable.selections))),
      ]

      public var snapshot: Snapshot

      public init(snapshot: Snapshot) {
        self.snapshot = snapshot
      }

      public init(starrable: Starrable) {
        self.init(snapshot: ["__typename": "AddStarPayload", "starrable": starrable.snapshot])
      }

      public var __typename: String {
        get {
          return snapshot["__typename"]! as! String
        }
        set {
          snapshot.updateValue(newValue, forKey: "__typename")
        }
      }

      /// The starrable.
      public var starrable: Starrable {
        get {
          return Starrable(snapshot: snapshot["starrable"]! as! Snapshot)
        }
        set {
          snapshot.updateValue(newValue.snapshot, forKey: "starrable")
        }
      }

      public struct Starrable: GraphQLSelectionSet {
        public static let possibleTypes = ["Repository", "Gist"]

        public static let selections: [GraphQLSelection] = [
          GraphQLTypeCase(
            variants: ["Repository": AsRepository.selections],
            default: [
              GraphQLField("__typename", type: .nonNull(.scalar(String.self))),
            ]
          )
        ]

        public var snapshot: Snapshot

        public init(snapshot: Snapshot) {
          self.snapshot = snapshot
        }

        public static func makeGist() -> Starrable {
          return Starrable(snapshot: ["__typename": "Gist"])
        }

        public static func makeRepository(id: GraphQLID, nameWithOwner: String, viewerHasStarred: Bool, stargazers: AsRepository.Stargazer) -> Starrable {
          return Starrable(snapshot: ["__typename": "Repository", "id": id, "nameWithOwner": nameWithOwner, "viewerHasStarred": viewerHasStarred, "stargazers": stargazers.snapshot])
        }

        public var __typename: String {
          get {
            return snapshot["__typename"]! as! String
          }
          set {
            snapshot.updateValue(newValue, forKey: "__typename")
          }
        }

        public var asRepository: AsRepository? {
          get {
            if !AsRepository.possibleTypes.contains(__typename) { return nil }
            return AsRepository(snapshot: snapshot)
          }
          set {
            guard let newValue = newValue else { return }
            snapshot = newValue.snapshot
          }
        }

        public struct AsRepository: GraphQLSelectionSet {
          public static let possibleTypes = ["Repository"]

          public static let selections: [GraphQLSelection] = [
            GraphQLField("__typename", type: .nonNull(.scalar(String.self))),
            GraphQLField("__typename", type: .nonNull(.scalar(String.self))),
            GraphQLField("id", type: .nonNull(.scalar(GraphQLID.self))),
            GraphQLField("nameWithOwner", type: .nonNull(.scalar(String.self))),
            GraphQLField("viewerHasStarred", type: .nonNull(.scalar(Bool.self))),
            GraphQLField("stargazers", type: .nonNull(.object(Stargazer.selections))),
          ]

          public var snapshot: Snapshot

          public init(snapshot: Snapshot) {
            self.snapshot = snapshot
          }

          public init(id: GraphQLID, nameWithOwner: String, viewerHasStarred: Bool, stargazers: Stargazer) {
            self.init(snapshot: ["__typename": "Repository", "id": id, "nameWithOwner": nameWithOwner, "viewerHasStarred": viewerHasStarred, "stargazers": stargazers.snapshot])
          }

          public var __typename: String {
            get {
              return snapshot["__typename"]! as! String
            }
            set {
              snapshot.updateValue(newValue, forKey: "__typename")
            }
          }

          public var id: GraphQLID {
            get {
              return snapshot["id"]! as! GraphQLID
            }
            set {
              snapshot.updateValue(newValue, forKey: "id")
            }
          }

          /// The repository's name with owner.
          public var nameWithOwner: String {
            get {
              return snapshot["nameWithOwner"]! as! String
            }
            set {
              snapshot.updateValue(newValue, forKey: "nameWithOwner")
            }
          }

          /// Returns a boolean indicating whether the viewing user has starred this starrable.
          public var viewerHasStarred: Bool {
            get {
              return snapshot["viewerHasStarred"]! as! Bool
            }
            set {
              snapshot.updateValue(newValue, forKey: "viewerHasStarred")
            }
          }

          /// A list of users who have starred this starrable.
          public var stargazers: Stargazer {
            get {
              return Stargazer(snapshot: snapshot["stargazers"]! as! Snapshot)
            }
            set {
              snapshot.updateValue(newValue.snapshot, forKey: "stargazers")
            }
          }

          public var fragments: Fragments {
            get {
              return Fragments(snapshot: snapshot)
            }
            set {
              snapshot += newValue.snapshot
            }
          }

          public struct Fragments {
            public var snapshot: Snapshot

            public var repositoryDetail: RepositoryDetail {
              get {
                return RepositoryDetail(snapshot: snapshot)
              }
              set {
                snapshot += newValue.snapshot
              }
            }
          }

          public struct Stargazer: GraphQLSelectionSet {
            public static let possibleTypes = ["StargazerConnection"]

            public static let selections: [GraphQLSelection] = [
              GraphQLField("__typename", type: .nonNull(.scalar(String.self))),
              GraphQLField("totalCount", type: .nonNull(.scalar(Int.self))),
            ]

            public var snapshot: Snapshot

            public init(snapshot: Snapshot) {
              self.snapshot = snapshot
            }

            public init(totalCount: Int) {
              self.init(snapshot: ["__typename": "StargazerConnection", "totalCount": totalCount])
            }

            public var __typename: String {
              get {
                return snapshot["__typename"]! as! String
              }
              set {
                snapshot.updateValue(newValue, forKey: "__typename")
              }
            }

            /// Identifies the total count of items in the connection.
            public var totalCount: Int {
              get {
                return snapshot["totalCount"]! as! Int
              }
              set {
                snapshot.updateValue(newValue, forKey: "totalCount")
              }
            }
          }
        }
      }
    }
  }
}

public final class RemoveStarMutation: GraphQLMutation {
  public static let operationString =
    "mutation RemoveStar($repositoryId: ID!) {\n  removeStar(input: {clientMutationId: \"11078247\", starrableId: $repositoryId}) {\n    __typename\n    starrable {\n      __typename\n      ... on Repository {\n        ...RepositoryDetail\n      }\n    }\n  }\n}"

  public static var requestString: String { return operationString.appending(RepositoryDetail.fragmentString) }

  public var repositoryId: GraphQLID

  public init(repositoryId: GraphQLID) {
    self.repositoryId = repositoryId
  }

  public var variables: GraphQLMap? {
    return ["repositoryId": repositoryId]
  }

  public struct Data: GraphQLSelectionSet {
    public static let possibleTypes = ["Mutation"]

    public static let selections: [GraphQLSelection] = [
      GraphQLField("removeStar", arguments: ["input": ["clientMutationId": "11078247", "starrableId": GraphQLVariable("repositoryId")]], type: .object(RemoveStar.selections)),
    ]

    public var snapshot: Snapshot

    public init(snapshot: Snapshot) {
      self.snapshot = snapshot
    }

    public init(removeStar: RemoveStar? = nil) {
      self.init(snapshot: ["__typename": "Mutation", "removeStar": removeStar.flatMap { $0.snapshot }])
    }

    /// Removes a star from a Starrable.
    public var removeStar: RemoveStar? {
      get {
        return (snapshot["removeStar"] as? Snapshot).flatMap { RemoveStar(snapshot: $0) }
      }
      set {
        snapshot.updateValue(newValue?.snapshot, forKey: "removeStar")
      }
    }

    public struct RemoveStar: GraphQLSelectionSet {
      public static let possibleTypes = ["RemoveStarPayload"]

      public static let selections: [GraphQLSelection] = [
        GraphQLField("__typename", type: .nonNull(.scalar(String.self))),
        GraphQLField("starrable", type: .nonNull(.object(Starrable.selections))),
      ]

      public var snapshot: Snapshot

      public init(snapshot: Snapshot) {
        self.snapshot = snapshot
      }

      public init(starrable: Starrable) {
        self.init(snapshot: ["__typename": "RemoveStarPayload", "starrable": starrable.snapshot])
      }

      public var __typename: String {
        get {
          return snapshot["__typename"]! as! String
        }
        set {
          snapshot.updateValue(newValue, forKey: "__typename")
        }
      }

      /// The starrable.
      public var starrable: Starrable {
        get {
          return Starrable(snapshot: snapshot["starrable"]! as! Snapshot)
        }
        set {
          snapshot.updateValue(newValue.snapshot, forKey: "starrable")
        }
      }

      public struct Starrable: GraphQLSelectionSet {
        public static let possibleTypes = ["Repository", "Gist"]

        public static let selections: [GraphQLSelection] = [
          GraphQLTypeCase(
            variants: ["Repository": AsRepository.selections],
            default: [
              GraphQLField("__typename", type: .nonNull(.scalar(String.self))),
            ]
          )
        ]

        public var snapshot: Snapshot

        public init(snapshot: Snapshot) {
          self.snapshot = snapshot
        }

        public static func makeGist() -> Starrable {
          return Starrable(snapshot: ["__typename": "Gist"])
        }

        public static func makeRepository(id: GraphQLID, nameWithOwner: String, viewerHasStarred: Bool, stargazers: AsRepository.Stargazer) -> Starrable {
          return Starrable(snapshot: ["__typename": "Repository", "id": id, "nameWithOwner": nameWithOwner, "viewerHasStarred": viewerHasStarred, "stargazers": stargazers.snapshot])
        }

        public var __typename: String {
          get {
            return snapshot["__typename"]! as! String
          }
          set {
            snapshot.updateValue(newValue, forKey: "__typename")
          }
        }

        public var asRepository: AsRepository? {
          get {
            if !AsRepository.possibleTypes.contains(__typename) { return nil }
            return AsRepository(snapshot: snapshot)
          }
          set {
            guard let newValue = newValue else { return }
            snapshot = newValue.snapshot
          }
        }

        public struct AsRepository: GraphQLSelectionSet {
          public static let possibleTypes = ["Repository"]

          public static let selections: [GraphQLSelection] = [
            GraphQLField("__typename", type: .nonNull(.scalar(String.self))),
            GraphQLField("__typename", type: .nonNull(.scalar(String.self))),
            GraphQLField("id", type: .nonNull(.scalar(GraphQLID.self))),
            GraphQLField("nameWithOwner", type: .nonNull(.scalar(String.self))),
            GraphQLField("viewerHasStarred", type: .nonNull(.scalar(Bool.self))),
            GraphQLField("stargazers", type: .nonNull(.object(Stargazer.selections))),
          ]

          public var snapshot: Snapshot

          public init(snapshot: Snapshot) {
            self.snapshot = snapshot
          }

          public init(id: GraphQLID, nameWithOwner: String, viewerHasStarred: Bool, stargazers: Stargazer) {
            self.init(snapshot: ["__typename": "Repository", "id": id, "nameWithOwner": nameWithOwner, "viewerHasStarred": viewerHasStarred, "stargazers": stargazers.snapshot])
          }

          public var __typename: String {
            get {
              return snapshot["__typename"]! as! String
            }
            set {
              snapshot.updateValue(newValue, forKey: "__typename")
            }
          }

          public var id: GraphQLID {
            get {
              return snapshot["id"]! as! GraphQLID
            }
            set {
              snapshot.updateValue(newValue, forKey: "id")
            }
          }

          /// The repository's name with owner.
          public var nameWithOwner: String {
            get {
              return snapshot["nameWithOwner"]! as! String
            }
            set {
              snapshot.updateValue(newValue, forKey: "nameWithOwner")
            }
          }

          /// Returns a boolean indicating whether the viewing user has starred this starrable.
          public var viewerHasStarred: Bool {
            get {
              return snapshot["viewerHasStarred"]! as! Bool
            }
            set {
              snapshot.updateValue(newValue, forKey: "viewerHasStarred")
            }
          }

          /// A list of users who have starred this starrable.
          public var stargazers: Stargazer {
            get {
              return Stargazer(snapshot: snapshot["stargazers"]! as! Snapshot)
            }
            set {
              snapshot.updateValue(newValue.snapshot, forKey: "stargazers")
            }
          }

          public var fragments: Fragments {
            get {
              return Fragments(snapshot: snapshot)
            }
            set {
              snapshot += newValue.snapshot
            }
          }

          public struct Fragments {
            public var snapshot: Snapshot

            public var repositoryDetail: RepositoryDetail {
              get {
                return RepositoryDetail(snapshot: snapshot)
              }
              set {
                snapshot += newValue.snapshot
              }
            }
          }

          public struct Stargazer: GraphQLSelectionSet {
            public static let possibleTypes = ["StargazerConnection"]

            public static let selections: [GraphQLSelection] = [
              GraphQLField("__typename", type: .nonNull(.scalar(String.self))),
              GraphQLField("totalCount", type: .nonNull(.scalar(Int.self))),
            ]

            public var snapshot: Snapshot

            public init(snapshot: Snapshot) {
              self.snapshot = snapshot
            }

            public init(totalCount: Int) {
              self.init(snapshot: ["__typename": "StargazerConnection", "totalCount": totalCount])
            }

            public var __typename: String {
              get {
                return snapshot["__typename"]! as! String
              }
              set {
                snapshot.updateValue(newValue, forKey: "__typename")
              }
            }

            /// Identifies the total count of items in the connection.
            public var totalCount: Int {
              get {
                return snapshot["totalCount"]! as! Int
              }
              set {
                snapshot.updateValue(newValue, forKey: "totalCount")
              }
            }
          }
        }
      }
    }
  }
}

public struct RepositoryDetail: GraphQLFragment {
  public static let fragmentString =
    "fragment RepositoryDetail on Repository {\n  __typename\n  id\n  nameWithOwner\n  viewerHasStarred\n  stargazers {\n    __typename\n    totalCount\n  }\n}"

  public static let possibleTypes = ["Repository"]

  public static let selections: [GraphQLSelection] = [
    GraphQLField("__typename", type: .nonNull(.scalar(String.self))),
    GraphQLField("id", type: .nonNull(.scalar(GraphQLID.self))),
    GraphQLField("nameWithOwner", type: .nonNull(.scalar(String.self))),
    GraphQLField("viewerHasStarred", type: .nonNull(.scalar(Bool.self))),
    GraphQLField("stargazers", type: .nonNull(.object(Stargazer.selections))),
  ]

  public var snapshot: Snapshot

  public init(snapshot: Snapshot) {
    self.snapshot = snapshot
  }

  public init(id: GraphQLID, nameWithOwner: String, viewerHasStarred: Bool, stargazers: Stargazer) {
    self.init(snapshot: ["__typename": "Repository", "id": id, "nameWithOwner": nameWithOwner, "viewerHasStarred": viewerHasStarred, "stargazers": stargazers.snapshot])
  }

  public var __typename: String {
    get {
      return snapshot["__typename"]! as! String
    }
    set {
      snapshot.updateValue(newValue, forKey: "__typename")
    }
  }

  public var id: GraphQLID {
    get {
      return snapshot["id"]! as! GraphQLID
    }
    set {
      snapshot.updateValue(newValue, forKey: "id")
    }
  }

  /// The repository's name with owner.
  public var nameWithOwner: String {
    get {
      return snapshot["nameWithOwner"]! as! String
    }
    set {
      snapshot.updateValue(newValue, forKey: "nameWithOwner")
    }
  }

  /// Returns a boolean indicating whether the viewing user has starred this starrable.
  public var viewerHasStarred: Bool {
    get {
      return snapshot["viewerHasStarred"]! as! Bool
    }
    set {
      snapshot.updateValue(newValue, forKey: "viewerHasStarred")
    }
  }

  /// A list of users who have starred this starrable.
  public var stargazers: Stargazer {
    get {
      return Stargazer(snapshot: snapshot["stargazers"]! as! Snapshot)
    }
    set {
      snapshot.updateValue(newValue.snapshot, forKey: "stargazers")
    }
  }

  public struct Stargazer: GraphQLSelectionSet {
    public static let possibleTypes = ["StargazerConnection"]

    public static let selections: [GraphQLSelection] = [
      GraphQLField("__typename", type: .nonNull(.scalar(String.self))),
      GraphQLField("totalCount", type: .nonNull(.scalar(Int.self))),
    ]

    public var snapshot: Snapshot

    public init(snapshot: Snapshot) {
      self.snapshot = snapshot
    }

    public init(totalCount: Int) {
      self.init(snapshot: ["__typename": "StargazerConnection", "totalCount": totalCount])
    }

    public var __typename: String {
      get {
        return snapshot["__typename"]! as! String
      }
      set {
        snapshot.updateValue(newValue, forKey: "__typename")
      }
    }

    /// Identifies the total count of items in the connection.
    public var totalCount: Int {
      get {
        return snapshot["totalCount"]! as! Int
      }
      set {
        snapshot.updateValue(newValue, forKey: "totalCount")
      }
    }
  }
}